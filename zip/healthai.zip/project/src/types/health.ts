export interface HealthMetric {
  date: string;
  heartRate: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  bloodGlucose: number;
  weight: number;
  temperature: number;
}

export interface Symptom {
  id: string;
  name: string;
  severity: 'mild' | 'moderate' | 'severe';
  duration: string;
}

export interface Disease {
  name: string;
  likelihood: number;
  symptoms: string[];
  description: string;
  recommendations: string[];
}

export interface TreatmentPlan {
  condition: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }>;
  lifestyle: string[];
  followUp: string[];
  warnings: string[];
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  medicalHistory: string[];
  allergies: string[];
  currentMedications: string[];
}