import { HealthMetric, Patient } from '../types/health';

export const mockPatient: Patient = {
  id: '1',
  name: 'John Doe',
  age: 35,
  gender: 'male',
  medicalHistory: ['Hypertension', 'Type 2 Diabetes'],
  allergies: ['Penicillin', 'Shellfish'],
  currentMedications: ['Metformin 500mg', 'Lisinopril 10mg']
};

export const mockHealthData: HealthMetric[] = [
  {
    date: '2024-01-01',
    heartRate: 72,
    bloodPressureSystolic: 130,
    bloodPressureDiastolic: 85,
    bloodGlucose: 120,
    weight: 175,
    temperature: 98.6
  },
  {
    date: '2024-01-07',
    heartRate: 75,
    bloodPressureSystolic: 128,
    bloodPressureDiastolic: 82,
    bloodGlucose: 115,
    weight: 174,
    temperature: 98.4
  },
  {
    date: '2024-01-14',
    heartRate: 73,
    bloodPressureSystolic: 125,
    bloodPressureDiastolic: 80,
    bloodGlucose: 118,
    weight: 173,
    temperature: 98.7
  },
  {
    date: '2024-01-21',
    heartRate: 71,
    bloodPressureSystolic: 122,
    bloodPressureDiastolic: 78,
    bloodGlucose: 110,
    weight: 172,
    temperature: 98.5
  },
  {
    date: '2024-01-28',
    heartRate: 74,
    bloodPressureSystolic: 120,
    bloodPressureDiastolic: 75,
    bloodGlucose: 108,
    weight: 171,
    temperature: 98.6
  }
];

export const commonSymptoms = [
  'Headache',
  'Fever',
  'Fatigue',
  'Cough',
  'Sore throat',
  'Nausea',
  'Dizziness',
  'Chest pain',
  'Shortness of breath',
  'Abdominal pain',
  'Joint pain',
  'Muscle aches',
  'Loss of appetite',
  'Difficulty sleeping',
  'Skin rash'
];