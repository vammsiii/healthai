import { Disease, TreatmentPlan, ChatMessage } from '../types/health';

export const simulateDiseasePrediction = (symptoms: string[]): Disease[] => {
  const diseaseDatabase = [
    {
      name: 'Common Cold',
      baseSymptoms: ['cough', 'sore throat', 'fatigue', 'headache'],
      description: 'A viral upper respiratory tract infection that is self-limiting.',
      recommendations: [
        'Get plenty of rest',
        'Stay hydrated',
        'Use over-the-counter pain relievers if needed',
        'Consider throat lozenges for sore throat'
      ]
    },
    {
      name: 'Influenza',
      baseSymptoms: ['fever', 'fatigue', 'muscle aches', 'headache', 'cough'],
      description: 'A viral infection that attacks your respiratory system.',
      recommendations: [
        'Rest and stay hydrated',
        'Antiviral medications may help if started early',
        'Monitor temperature and seek care if fever persists',
        'Isolate to prevent spread to others'
      ]
    },
    {
      name: 'Migraine',
      baseSymptoms: ['headache', 'nausea', 'dizziness'],
      description: 'A neurological condition characterized by recurrent moderate to severe headaches.',
      recommendations: [
        'Rest in a quiet, dark room',
        'Apply cold or warm compress to head/neck',
        'Stay hydrated',
        'Consider over-the-counter pain relievers'
      ]
    },
    {
      name: 'Gastroenteritis',
      baseSymptoms: ['nausea', 'abdominal pain', 'fatigue', 'loss of appetite'],
      description: 'Inflammation of the stomach and intestines, often called stomach flu.',
      recommendations: [
        'Stay hydrated with clear fluids',
        'Follow BRAT diet (bananas, rice, applesauce, toast)',
        'Rest and avoid dairy products',
        'Seek medical care if symptoms worsen'
      ]
    }
  ];

  const predictions: Disease[] = [];
  const symptomLower = symptoms.map(s => s.toLowerCase());

  diseaseDatabase.forEach(disease => {
    const matchCount = disease.baseSymptoms.filter(symptom => 
      symptomLower.some(userSymptom => userSymptom.includes(symptom))
    ).length;

    if (matchCount > 0) {
      const likelihood = Math.min((matchCount / disease.baseSymptoms.length) * 100, 85);
      predictions.push({
        name: disease.name,
        likelihood: Math.round(likelihood),
        symptoms: disease.baseSymptoms,
        description: disease.description,
        recommendations: disease.recommendations
      });
    }
  });

  return predictions.sort((a, b) => b.likelihood - a.likelihood).slice(0, 3);
};

export const generateTreatmentPlan = (condition: string): TreatmentPlan => {
  const treatmentPlans: Record<string, TreatmentPlan> = {
    'hypertension': {
      condition: 'Hypertension',
      medications: [
        { name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', duration: 'Ongoing' },
        { name: 'Amlodipine', dosage: '5mg', frequency: 'Once daily', duration: 'Ongoing' }
      ],
      lifestyle: [
        'Reduce sodium intake to less than 2,300mg daily',
        'Exercise regularly (30 minutes, 5 days a week)',
        'Maintain healthy weight',
        'Limit alcohol consumption',
        'Manage stress through relaxation techniques'
      ],
      followUp: [
        'Blood pressure monitoring every 2-4 weeks initially',
        'Regular follow-up visits every 3 months',
        'Annual comprehensive metabolic panel',
        'Cardiovascular risk assessment'
      ],
      warnings: [
        'Monitor for signs of hypotension',
        'Report persistent cough or swelling',
        'Do not stop medications suddenly'
      ]
    },
    'diabetes': {
      condition: 'Type 2 Diabetes',
      medications: [
        { name: 'Metformin', dosage: '500mg', frequency: 'Twice daily', duration: 'Ongoing' },
        { name: 'Glipizide', dosage: '5mg', frequency: 'Once daily', duration: 'Ongoing' }
      ],
      lifestyle: [
        'Follow diabetic diet with carbohydrate counting',
        'Regular physical activity (150 minutes per week)',
        'Monitor blood glucose levels daily',
        'Maintain healthy weight',
        'Regular foot care and inspection'
      ],
      followUp: [
        'HbA1c testing every 3 months',
        'Annual eye examination',
        'Regular kidney function monitoring',
        'Cardiovascular risk assessment'
      ],
      warnings: [
        'Watch for signs of hypoglycemia',
        'Monitor for diabetic complications',
        'Report any foot injuries immediately'
      ]
    }
  };

  return treatmentPlans[condition.toLowerCase()] || {
    condition: condition,
    medications: [
      { name: 'Consult healthcare provider', dosage: 'N/A', frequency: 'N/A', duration: 'N/A' }
    ],
    lifestyle: ['Maintain healthy lifestyle habits', 'Follow medical advice'],
    followUp: ['Schedule appointment with healthcare provider'],
    warnings: ['Seek immediate medical attention if symptoms worsen']
  };
};

// Enhanced AI response system with specific medical knowledge
const medicalKnowledgeBase = {
  // Blood Pressure Related
  'high blood pressure': {
    symptoms: 'High blood pressure (hypertension) often has no symptoms, which is why it\'s called the "silent killer." However, some people may experience:\n\n• Headaches (especially in the morning)\n• Dizziness or lightheadedness\n• Nausea\n• Shortness of breath\n• Blurred vision\n• Chest pain\n• Nosebleeds (rare)\n\nNormal blood pressure is less than 120/80 mmHg. High blood pressure is 130/80 mmHg or higher.',
    management: 'Managing high blood pressure involves:\n\n• Taking prescribed medications as directed\n• Reducing sodium intake (less than 2,300mg daily)\n• Regular exercise (30 minutes, 5 days/week)\n• Maintaining healthy weight\n• Limiting alcohol consumption\n• Managing stress\n• Regular monitoring at home\n• Avoiding tobacco products',
    when_to_seek_help: 'Seek immediate medical attention if you experience severe headache, chest pain, difficulty breathing, or blood pressure readings consistently above 180/120 mmHg.'
  },

  // Sleep Related
  'sleep': {
    quality_tips: 'To improve sleep quality:\n\n• Maintain a consistent sleep schedule (same bedtime/wake time)\n• Create a relaxing bedtime routine\n• Keep bedroom cool, dark, and quiet\n• Avoid screens 1 hour before bed\n• Limit caffeine after 2 PM\n• Exercise regularly (but not close to bedtime)\n• Avoid large meals before sleep\n• Consider relaxation techniques like meditation\n• Ensure comfortable mattress and pillows',
    sleep_hygiene: 'Good sleep hygiene includes:\n\n• 7-9 hours of sleep for adults\n• Consistent sleep-wake cycle\n• Comfortable sleep environment\n• Avoiding stimulants before bed\n• Managing stress and anxiety\n• Regular physical activity\n• Exposure to natural light during the day',
    disorders: 'Common sleep disorders include sleep apnea, insomnia, restless leg syndrome, and narcolepsy. If you consistently have trouble sleeping despite good sleep hygiene, consult a healthcare provider.'
  },

  // Headache Related
  'headache': {
    types: 'Common types of headaches:\n\n• **Tension headaches**: Most common, feel like a tight band around the head\n• **Migraines**: Severe, often one-sided, with nausea and light sensitivity\n• **Cluster headaches**: Severe pain around one eye, occur in clusters\n• **Sinus headaches**: Associated with sinus congestion and facial pressure',
    persistent_care: 'For persistent headaches:\n\n• Keep a headache diary to identify triggers\n• Stay hydrated (8-10 glasses of water daily)\n• Maintain regular sleep schedule\n• Manage stress through relaxation techniques\n• Apply cold or warm compress\n• Consider over-the-counter pain relievers (follow package directions)\n• Avoid known triggers (certain foods, stress, lack of sleep)',
    red_flags: 'Seek immediate medical attention for:\n\n• Sudden, severe headache ("worst headache of your life")\n• Headache with fever, stiff neck, or rash\n• Headache after head injury\n• Progressive worsening headaches\n• Headache with vision changes, weakness, or confusion\n• New headache pattern in people over 50'
  },

  // Diabetes Related
  'diabetes': {
    management: 'Diabetes management involves:\n\n• **Blood sugar monitoring**: Check levels as recommended by your doctor\n• **Medication adherence**: Take prescribed medications consistently\n• **Healthy eating**: Focus on complex carbs, lean proteins, healthy fats\n• **Regular exercise**: 150 minutes of moderate activity per week\n• **Weight management**: Maintain healthy BMI\n• **Stress management**: Practice relaxation techniques\n• **Regular check-ups**: Monitor A1C, blood pressure, cholesterol',
    diet_tips: 'Diabetic diet recommendations:\n\n• Choose complex carbohydrates (whole grains, vegetables)\n• Include lean proteins (fish, poultry, legumes)\n• Eat healthy fats (nuts, olive oil, avocado)\n• Limit processed foods and added sugars\n• Control portion sizes\n• Eat regular meals to maintain stable blood sugar\n• Stay hydrated with water',
    complications: 'Diabetes complications can include heart disease, stroke, kidney disease, eye problems, nerve damage, and foot problems. Regular monitoring and good management can prevent or delay these complications.'
  },

  // General Health
  'exercise': {
    benefits: 'Regular exercise provides numerous health benefits:\n\n• Improves cardiovascular health\n• Strengthens muscles and bones\n• Enhances mental health and mood\n• Helps maintain healthy weight\n• Reduces risk of chronic diseases\n• Improves sleep quality\n• Boosts immune system\n• Increases energy levels',
    recommendations: 'Exercise recommendations for adults:\n\n• 150 minutes of moderate-intensity aerobic activity per week\n• 2 days of muscle-strengthening activities\n• Include flexibility and balance exercises\n• Start slowly if you\'re new to exercise\n• Choose activities you enjoy\n• Consult healthcare provider before starting intense programs'
  },

  'nutrition': {
    balanced_diet: 'A balanced diet includes:\n\n• **Fruits and vegetables**: 5-9 servings daily\n• **Whole grains**: Choose brown rice, whole wheat, oats\n• **Lean proteins**: Fish, poultry, beans, nuts\n• **Healthy fats**: Olive oil, avocados, nuts\n• **Dairy or alternatives**: Low-fat options\n• **Hydration**: 8-10 glasses of water daily\n• **Limit**: Processed foods, added sugars, excessive sodium'
  }
};

export const simulateAIResponse = async (message: string): Promise<string> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

  const messageLower = message.toLowerCase();
  
  // Emergency situations - highest priority
  if (messageLower.includes('chest pain') || messageLower.includes('heart attack') || 
      messageLower.includes('difficulty breathing') || messageLower.includes('can\'t breathe') ||
      messageLower.includes('severe headache') || messageLower.includes('stroke') ||
      messageLower.includes('unconscious') || messageLower.includes('seizure')) {
    return "🚨 **MEDICAL EMERGENCY** 🚨\n\nBased on your symptoms, this could be a serious medical emergency. Please:\n\n• **Call 911 immediately** or go to the nearest emergency room\n• Do not drive yourself - have someone else drive or call an ambulance\n• If experiencing chest pain, chew an aspirin if not allergic\n• Stay calm and follow emergency dispatcher instructions\n\nTime is critical in medical emergencies. Please seek immediate professional medical care.";
  }

  // Greeting responses
  if (messageLower.includes('hello') || messageLower.includes('hi') || messageLower.includes('hey') ||
      messageLower.includes('good morning') || messageLower.includes('good afternoon')) {
    return "Hello! I'm HealthAI, your intelligent healthcare assistant. I'm here to provide evidence-based health information and guidance. I can help you with:\n\n• Understanding symptoms and conditions\n• Health management tips\n• Medication information\n• Lifestyle recommendations\n• When to seek medical care\n\nWhat specific health question can I help you with today?";
  }

  // Blood pressure related questions
  if (messageLower.includes('blood pressure') || messageLower.includes('hypertension') || 
      messageLower.includes('high blood pressure')) {
    if (messageLower.includes('symptom')) {
      return medicalKnowledgeBase['high blood pressure'].symptoms + '\n\n' + medicalKnowledgeBase['high blood pressure'].when_to_seek_help;
    } else {
      return medicalKnowledgeBase['high blood pressure'].management + '\n\n**Important**: Always follow your healthcare provider\'s specific recommendations for your individual situation.';
    }
  }

  // Sleep related questions
  if (messageLower.includes('sleep') || messageLower.includes('insomnia') || 
      messageLower.includes('can\'t sleep') || messageLower.includes('sleep quality')) {
    if (messageLower.includes('improve') || messageLower.includes('better') || messageLower.includes('quality')) {
      return medicalKnowledgeBase.sleep.quality_tips + '\n\n' + medicalKnowledgeBase.sleep.disorders;
    } else {
      return medicalKnowledgeBase.sleep.sleep_hygiene + '\n\nIf sleep problems persist for more than 2-3 weeks, consider consulting a healthcare provider or sleep specialist.';
    }
  }

  // Headache related questions
  if (messageLower.includes('headache') || messageLower.includes('migraine')) {
    if (messageLower.includes('persistent') || messageLower.includes('chronic') || 
        messageLower.includes('won\'t go away') || messageLower.includes('keeps coming back')) {
      return medicalKnowledgeBase.headache.persistent_care + '\n\n**Red Flags - Seek immediate care for:**\n' + medicalKnowledgeBase.headache.red_flags;
    } else {
      return medicalKnowledgeBase.headache.types + '\n\n**General headache management:**\n• Stay hydrated\n• Get adequate sleep\n• Manage stress\n• Apply cold/warm compress\n• Consider OTC pain relievers (follow directions)\n\nIf headaches are frequent or severe, consult a healthcare provider.';
    }
  }

  // Diabetes related questions
  if (messageLower.includes('diabetes') || messageLower.includes('blood sugar') || 
      messageLower.includes('glucose') || messageLower.includes('diabetic')) {
    if (messageLower.includes('management') || messageLower.includes('manage') || 
        messageLower.includes('control')) {
      return medicalKnowledgeBase.diabetes.management + '\n\n**Diet Tips:**\n' + medicalKnowledgeBase.diabetes.diet_tips;
    } else {
      return medicalKnowledgeBase.diabetes.management + '\n\n**Important**: Work closely with your healthcare team to develop a personalized diabetes management plan.';
    }
  }

  // Exercise related questions
  if (messageLower.includes('exercise') || messageLower.includes('workout') || 
      messageLower.includes('physical activity') || messageLower.includes('fitness')) {
    return medicalKnowledgeBase.exercise.benefits + '\n\n**Exercise Recommendations:**\n' + medicalKnowledgeBase.exercise.recommendations;
  }

  // Nutrition/diet related questions
  if (messageLower.includes('diet') || messageLower.includes('nutrition') || 
      messageLower.includes('eating') || messageLower.includes('food')) {
    return medicalKnowledgeBase.nutrition.balanced_diet + '\n\n**Remember**: Individual nutritional needs may vary. Consult with a registered dietitian for personalized nutrition advice.';
  }

  // Medication related questions
  if (messageLower.includes('medication') || messageLower.includes('medicine') || 
      messageLower.includes('drug') || messageLower.includes('pill')) {
    return "**Medication Safety Guidelines:**\n\n• Take medications exactly as prescribed\n• Don't skip doses or stop suddenly without consulting your doctor\n• Be aware of potential side effects\n• Check for drug interactions\n• Store medications properly\n• Keep an updated medication list\n• Use the same pharmacy when possible\n• Ask questions about new prescriptions\n\n**Important**: Never adjust medication dosages without consulting your healthcare provider. If you experience concerning side effects, contact your doctor immediately.";
  }

  // Symptom-related questions
  if (messageLower.includes('symptom') || messageLower.includes('feel sick') || 
      messageLower.includes('not feeling well') || messageLower.includes('pain')) {
    return "When experiencing symptoms, it's important to:\n\n• **Document symptoms**: Note when they started, severity, and any triggers\n• **Monitor changes**: Keep track of whether symptoms improve or worsen\n• **Stay hydrated**: Drink plenty of fluids\n• **Rest**: Give your body time to recover\n• **Avoid self-diagnosis**: Symptoms can have multiple causes\n\n**Seek medical attention if you experience:**\n• Severe or worsening symptoms\n• Symptoms lasting more than a few days\n• Fever above 103°F (39.4°C)\n• Difficulty breathing\n• Severe pain\n• Signs of dehydration\n\n**Remember**: This information is for educational purposes only and doesn't replace professional medical evaluation.";
  }

  // Mental health related
  if (messageLower.includes('anxiety') || messageLower.includes('depression') || 
      messageLower.includes('stress') || messageLower.includes('mental health')) {
    return "**Mental Health Support:**\n\nMental health is just as important as physical health. Here are some strategies:\n\n• **Stress Management**: Practice deep breathing, meditation, or yoga\n• **Regular Exercise**: Physical activity can improve mood\n• **Healthy Sleep**: Maintain consistent sleep schedule\n• **Social Connection**: Stay connected with friends and family\n• **Professional Help**: Don't hesitate to seek counseling or therapy\n• **Limit Stressors**: Identify and manage stress triggers\n• **Mindfulness**: Practice being present in the moment\n\n**Seek immediate help if you experience:**\n• Thoughts of self-harm\n• Severe depression or anxiety\n• Inability to function in daily life\n\n**Crisis Resources**: National Suicide Prevention Lifeline: 988\n\n**Remember**: Mental health treatment is effective, and seeking help is a sign of strength.";
  }

  // Default response for unrecognized questions
  return "Thank you for your health question. While I can provide general health information, I'd recommend being more specific about your concern so I can give you the most relevant and helpful information.\n\n**I can help with questions about:**\n• Specific symptoms or conditions\n• Medication information\n• Lifestyle and wellness tips\n• When to seek medical care\n• Disease prevention\n• Health management strategies\n\n**For example, you could ask:**\n• \"What are the symptoms of high blood pressure?\"\n• \"How can I improve my sleep quality?\"\n• \"What should I know about managing diabetes?\"\n\n**Important reminder**: This information is for educational purposes only and should not replace professional medical advice. Always consult with qualified healthcare providers for diagnosis and treatment decisions.\n\nWhat specific health topic would you like to know more about?";
};